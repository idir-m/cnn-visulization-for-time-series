# CNN visualization for time series

Front end project to help visualize and understand convolutional neural networks applied to time series .

## Installation

clone the project.

```bash
git clone https://github.com/idir-m/cnn-visulization-for-time-series.git
```

## Usage

```bash
cd cnn-visualization-for-time-series

npm install

npm run dev
```